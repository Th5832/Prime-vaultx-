# Prime VaultX website

A beginner-friendly, responsive static storefront built with HTML, CSS, and JavaScript.

## Files
- `index.html` — page content and product cards
- `style.css` — dark neon responsive design
- `script.js` — product search, category filters, order dialog, and WhatsApp order message

## Important before publishing
1. The listed products and prices are samples. Edit them in `index.html`.
2. In `script.js`, replace `REPLACE_WITH_YOUR_WHATSAPP_NUMBER` with your WhatsApp number in international format, digits only (no `+`, spaces, or dashes). Example format only: `919876543210`.
3. Replace placeholder email, phone, and city in the footer of `index.html`.
4. Update the footer terms/privacy links and social links to your real pages. Remove any link you do not use.
5. Only list products/services you are authorized to sell. Confirm applicable game/platform rules, local laws, payment rules, delivery terms, and refund policy before accepting orders.
6. Never ask customers for passwords or OTPs. Use a legitimate payment provider and show its real payment link only after setting up your account.

## Preview locally
Open `index.html` in a web browser. All three files must stay together in the same folder.

## Publish free with GitHub Pages
1. Create or sign in to an account at https://github.com/
2. Click **+** → **New repository**.
3. Name it `prime-vaultx`, select **Public**, and create the repository.
4. Choose **Add file** → **Upload files**.
5. Upload `index.html`, `style.css`, and `script.js` from this folder.
6. Click **Commit changes**.
7. Open repository **Settings** → **Pages**.
8. Under **Build and deployment**, choose **Deploy from a branch**.
9. Choose branch `main` and folder `/(root)`, then click **Save**.
10. Wait a few minutes. The Pages section will show the published URL, usually:
   `https://YOUR-GITHUB-USERNAME.github.io/prime-vaultx/`

If you rename the repository, your URL changes. The repository must contain `index.html` in its root folder.

## Edit products and prices
Each product is an `<article class="product-card">` in `index.html`. Change the product title, description, price, `data-name`, and button's `data-product` / `data-price` values together. Use `data-category="topups"`, `giftcards`, `memberships`, or `services`.

## Limitations
This is a static demo storefront. It does not have user accounts, a real payment checkout, stock management, a database, or an admin dashboard. Order buttons prepare a WhatsApp message only after you add your own number.
